create definer = root@localhost trigger trg_valida_data_gasto
    before insert
    on gasto
    for each row
BEGIN
	DECLARE v_data_inicio DATE;
    DECLARE v_data_fim DATE;
    
    IF NEW.id_planejamento IS NOT NULL THEN
		
        SELECT data_inicio, data_fim INTO v_data_inicio, v_data_fim
        FROM PlanejamentoFinanceiro
        WHERE id_planejamento = NEW.id_planejamento;
        
        IF NEW.data < v_data_inicio OR NEW.data > v_data_fim THEN
			SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Erro; Data do gasto não está dentro do período do Planejamento Financeiro';
		END IF;
        
	END IF;
    
END;

