create
    definer = root@localhost function fn_total_gasto_usuario(p_id_usuario int) returns decimal(10, 2) deterministic
BEGIN

    DECLARE total DECIMAL(10,2);

    SELECT SUM(valor)
    INTO total
    FROM Gasto
    WHERE id_usuario = p_id_usuario;

    RETURN IFNULL(total, 0);

END;

