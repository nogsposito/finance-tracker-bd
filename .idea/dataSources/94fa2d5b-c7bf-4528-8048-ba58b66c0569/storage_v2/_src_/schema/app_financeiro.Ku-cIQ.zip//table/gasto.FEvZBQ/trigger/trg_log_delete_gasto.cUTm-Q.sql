create definer = root@localhost trigger trg_log_delete_gasto
    after delete
    on gasto
    for each row
BEGIN
	INSERT INTO LogGasto (acao, id_gasto_excluido, valor_antigo)
    VALUES ('EXCLUSAO', OLD.id_gasto, OLD.valor);
END;

